import 'dart:convert';
import 'package:http/http.dart' as http;

class WordMeaning {
  final String partOfSpeech;
  final List<String> definitions;

  WordMeaning({required this.partOfSpeech, required this.definitions});
}

class WordDefinition {
  final String word;
  final String? phonetic;
  final List<WordMeaning> meanings;

  final String language;

  WordDefinition({
    required this.word,
    required this.meanings,
    required this.language,
    this.phonetic,
  });

  String toDescriptionText() {
    final buffer = StringBuffer();
    if (phonetic != null && phonetic!.isNotEmpty) {
      buffer.writeln('[$phonetic]');
    }
    for (final meaning in meanings) {
      buffer.writeln('${meaning.partOfSpeech}:');
      for (final def in meaning.definitions) {
        buffer.writeln('• $def');
      }
    }
    return buffer.toString().trim();
  }
}

class DictionaryService {
  static const _baseUrl = 'https://api.dictionaryapi.dev/api/v2/entries';

  static Future<WordDefinition?> lookupWord(String word) async {
    final trimmed = word.trim();
    if (trimmed.isEmpty) return null;

    final ptResult = await _fetchFromLanguage(trimmed, 'pt-BR');
    if (ptResult != null) return ptResult;

    return _fetchFromLanguage(trimmed, 'en');
  }

  static Future<WordDefinition?> _fetchFromLanguage(
    String word,
    String languageCode,
  ) async {
    final uri = Uri.parse('$_baseUrl/$languageCode/${Uri.encodeComponent(word)}');

    final response = await http.get(uri).timeout(const Duration(seconds: 10));

    if (response.statusCode == 404) {
      return null;
    }
    if (response.statusCode != 200) {
      throw Exception(
        'Erro ao consultar o dicionário (HTTP ${response.statusCode})',
      );
    }

    final List<dynamic> data = jsonDecode(response.body);
    if (data.isEmpty) return null;

    final entry = data.first as Map<String, dynamic>;

    final meaningsJson = (entry['meanings'] as List<dynamic>?) ?? [];
    final meanings = meaningsJson
        .map((m) {
          final map = m as Map<String, dynamic>;
          final defsJson = (map['definitions'] as List<dynamic>?) ?? [];
          final defs = defsJson
              .map((d) =>
                  (d as Map<String, dynamic>)['definition']?.toString() ?? '')
              .where((d) => d.isNotEmpty)
              .toList();
          return WordMeaning(
            partOfSpeech: map['partOfSpeech']?.toString() ?? '—',
            definitions: defs,
          );
        })
        .where((m) => m.definitions.isNotEmpty)
        .toList();

    if (meanings.isEmpty) return null;

    return WordDefinition(
      word: entry['word']?.toString() ?? word,
      phonetic: entry['phonetic']?.toString(),
      meanings: meanings,
      language: languageCode,
    );
  }
}
